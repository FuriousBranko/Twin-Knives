# Advanced search form with PHP and MySQL
Exercise files for the course **Advanced search form with PHP and MySQL**
