<?php

defined("DB_HOST")
    || define("DB_HOST", 'localhost');

defined("DB_NAME")
    || define("DB_NAME", 'search');

defined("DB_USER")
    || define("DB_USER", '');

defined("DB_PASSWORD")
    || define("DB_PASSWORD", '');